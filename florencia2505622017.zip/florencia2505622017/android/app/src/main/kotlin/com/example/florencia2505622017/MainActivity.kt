package com.example.florencia2505622017

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
