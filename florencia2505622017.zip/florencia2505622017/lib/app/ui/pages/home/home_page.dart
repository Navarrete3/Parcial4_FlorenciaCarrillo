import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class HomePage extends StatefulWidget {
  const HomePage({ Key? key }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  List<Marker> allMarkers = [];

  @override
  void initState(){
    super.initState();
    allMarkers.add(Marker(
      markerId: const MarkerId('Arce'),
      draggable: false,
      onTap: (){
        print('Marker Tapped');
      },
      position: const LatLng(13.699727, -89.2003444),
      infoWindow: const InfoWindow(title: 'Sucursal Arce', snippet: 'Sucursal Calle Arce')
    ));

    allMarkers.add(Marker(
      markerId: const MarkerId('Salvador del Mundo'),
      draggable: false,
      onTap: (){
        print('Marker Tapped');
      },
      position: const LatLng(13.7013266,-89.2266226),
      infoWindow: const InfoWindow(title: 'Sucusal Salvador del Mundo', snippet: 'Sucusal Salvador del Mundo')
    ));

    allMarkers.add(Marker(
      markerId: const MarkerId('Soyapango'),
      draggable: false,
      onTap: (){
        print('Marker Tapped');
      },
      position: const LatLng(13.7151697,-89.1439588),
      infoWindow: const InfoWindow(title: 'Sucursal Soyapango', snippet: 'Sucursal Soyapango')
    ));

    allMarkers.add(Marker(
      markerId: const MarkerId('San Jacinto'),
      draggable: false,
      onTap: (){
        print('Marker Tapped');
      },
      position: const LatLng(13.6879421,-89.1923235),
      infoWindow: const InfoWindow(title: 'Sucursal San Jacinto', snippet: 'Sucursal San Jacinto')
    ));

  }

  final _initialCameraPosition = const CameraPosition(
    target: LatLng(13.699727, -89.2003444),
    zoom: 10,
    );


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MovilSV - Sucursales de la zona central'),
      ),
      body: GoogleMap(
        initialCameraPosition: _initialCameraPosition,
        markers: Set.from(allMarkers),
      ),
    );
  }
}